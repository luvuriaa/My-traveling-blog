window.alert("Tip: hover over the images to see a zoom effect and click on ipod wheel to hear music!");

        
function showToast(message) {
    const container = document.getElementById('toast-container');
    
    // Create the notification element
    const toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.innerText = message;
    
    container.appendChild(toast);
    
    // Automatically remove it after 3 seconds
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 500);
    }, 3000);
}

function focusImage(element) {
    // Check if it's already focused
    if (element.classList.contains('focused')) {
        element.classList.remove('focused');
        element.style.position = "relative";
        element.style.top = "0";
        element.style.left = "0";
        element.style.transform = "rotate(3deg)";
    } else {
        // "Pick up" the photo
        element.classList.add('focused');
        element.style.position = "fixed";
        element.style.top = "50%";
        element.style.left = "50%";
        element.style.transform = "translate(-50%, -50%) scale(2)";
        element.style.zIndex = "2000";
    }
}

// Get the button
const topBtn = document.getElementById("backToTop");

// When the user scrolls down 300px from the top, show the button
window.onscroll = function() {
    if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
        topBtn.style.display = "flex";
    } else {
        topBtn.style.display = "none";
    }
};

// When the user clicks on the button, scroll to the top
topBtn.onclick = function() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth' // This makes the scroll nice and slow
    });
};