window.alert("Tip: hover over the images to see a zoom effect and click on ipod wheel to hear music!");

let currentPosition = 0;

function moveCarousel(direction) {
    const track = document.querySelector('.carousel-track');
    const totalBoxes = 5;
    const visibleBoxes = 3; 
    const maxIndex = totalBoxes - visibleBoxes; // For 5 boxes, this is 2

    // Update position
    currentPosition += direction;

    // Boundary checks so it doesn't slide into empty space
    if (currentPosition < 0) {
        currentPosition = 0;
    }
    if (currentPosition > maxIndex) {
        currentPosition = maxIndex;
    }

    // Move by 33.33% for each step since 3 boxes are visible
    const moveAmount = currentPosition * (100 / visibleBoxes);
    
    track.style.transform = `translateX(-${moveAmount}%)`;
}


function showToast(message) {
    const container = document.getElementById('toast-container');
    
    // Create the notification element
    const toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.innerText = message;
    
    container.appendChild(toast);
    
    // Automatically remove it after 3 seconds
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 500);
    }, 3000);
}


document.querySelectorAll('.read-btn').forEach((btn) => {
    btn.addEventListener('click', (e) => {
        // 1. Stop the immediate jump
        e.preventDefault(); 
        
        // 2. Get the link destination
        const destination = btn.getAttribute('href');
        
        // 3. Show the Toast feedback (Standard 3A-AP-19)
        showToast("Opening " + btn.parentElement.querySelector('.day-label').innerText + "...");
        
        // 4. Wait 1 second (so the user sees the toast) then change the page
        setTimeout(() => {
            window.location.href = destination;
        }, 1000);
    });
});


// Function to format seconds into 0:00 style
function formatTime(seconds) {
    let min = Math.floor(seconds / 60);
    let sec = Math.floor(seconds % 60);
    if (sec < 10) sec = '0' + sec;
    return min + ":" + sec;
}

// This runs as soon as the page loads to set the "Total Time" for each song
document.querySelectorAll('audio').forEach(song => {
    song.onloadedmetadata = () => {
        const durationEl = document.getElementById('duration-' + song.id);
        if (durationEl) {
            durationEl.innerText = formatTime(song.duration);
        }
    };
});

function toggleMusic(songId) {
    const song = document.getElementById(songId);
    const wrapper = song.parentElement;
    const notes = document.querySelector('.music-notes');
    
    // Mapping IDs to pretty names for the toast
    const songNames = {
        'song1': 'Headphones On',
        'song2': 'Cherish the Day',
        'song3': 'City of Stars'
    };

    if (!song.paused) {
        // --- ACTION: PAUSE ---
        song.pause();
        wrapper.classList.remove('is-playing');
        if (notes) notes.style.display = 'none';
    } else {
        // --- ACTION: PLAY ---
        // 1. Reset all other iPods and Songs
        document.querySelectorAll('audio').forEach(s => s.pause());
        document.querySelectorAll('.ipod-wrapper').forEach(w => w.classList.remove('is-playing'));

        // 2. Start this song
        song.play();
        wrapper.classList.add('is-playing');
        if (notes) notes.style.display = 'block';

        // 3. SHOW THE TOAST (This was missing!)
        showToast("Now Playing: " + (songNames[songId] || "Music"));

        // 4. DATA VISUALIZATION (Progress Bar)
        song.ontimeupdate = () => {
            const bar = document.getElementById('progress-' + songId);
            const current = document.getElementById('current-' + songId);
            const duration = document.getElementById('duration-' + songId);
            
            if (bar) {
                const percent = (song.currentTime / song.duration) * 100;
                bar.style.width = percent + "%";
            }
            
            if (current) current.innerText = formatTime(song.currentTime);
            if (duration && song.duration) duration.innerText = formatTime(song.duration);
        };
    }
}

document.addEventListener('DOMContentLoaded', () => {
            const articleContent = document.querySelector('.main-article-text');
            const readingProgressBar = document.getElementById('readingProgressBar');
            const interactiveImages = document.querySelectorAll('.interactive-img');

            if (!articleContent || !readingProgressBar) return;

            // --- Reading Progress Bar (3A-DA-11: Data Visualization) ---
            const updateProgressBar = () => {
                const scrollableHeight = articleContent.scrollHeight - articleContent.clientHeight;
                const scrolled = articleContent.scrollTop;
                const progress = (scrolled / scrollableHeight) * 100;
                readingProgressBar.style.width = `${progress}%`;
            };

            // Listen to scroll events on the article content
            articleContent.addEventListener('scroll', updateProgressBar);
            // Initial update
            updateProgressBar();

            // --- Interactive Images (3A-AP-19: User Feedback) ---
            interactiveImages.forEach(img => {
                img.addEventListener('click', () => {
                    img.classList.toggle('zoomed'); // Toggle a zoom class
                });
                // Optional: Add a simple pop-out animation on hover
                img.addEventListener('mouseenter', () => img.style.transform = 'scale(1.03) rotate(2deg)');
                img.addEventListener('mouseleave', () => img.style.transform = 'scale(1) rotate(0deg)');
            });
        });

// Get the button
const topBtn = document.getElementById("backToTop");

// When the user scrolls down 300px from the top, show the button
window.onscroll = function() {
    if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
        topBtn.style.display = "flex";
    } else {
        topBtn.style.display = "none";
    }
};

// When the user clicks on the button, scroll to the top
topBtn.onclick = function() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth' // This makes the scroll nice and slow
    });
};